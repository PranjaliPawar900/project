package student.studentmanagementsystem.dao;

import student.studentmanagementsystem.entity.Admin;

public interface AdminDao {
    Admin getAdminByUsername(String username, String password);
}
