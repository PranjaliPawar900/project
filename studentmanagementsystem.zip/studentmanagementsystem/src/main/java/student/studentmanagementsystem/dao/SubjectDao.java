package student.studentmanagementsystem.dao;

import java.util.List;
import student.studentmanagementsystem.entity.Subject;

public interface SubjectDao {
    void saveSubject(Subject subject);
    Subject getSubjectById(int id);
    List<Subject> getAllSubjects();
    void updateSubject(Subject subject);
    void deleteSubject(int id);
}
