package student.studentmanagementsystem.dao;

import student.studentmanagementsystem.entity.Department;

import java.util.List;

public interface DepartmentDao {

    void addDepartment(Department department);

    Department getDepartmentById(int departmentId);

    List<Department> getAllDepartments();

    void updateDepartment(Department department); // Accept the whole Department object

    void deleteDepartment(int departmentId);

    void saveDepartment(Department department);

	Department getDepartmentByName(String departmentName);

	boolean existsByName(String departmentName);
	
    
}
