package student.studentmanagementsystem.dao;

import student.studentmanagementsystem.entity.User;

public interface UserDao {
	boolean login(String username, String password);
    boolean register(User user);
}
