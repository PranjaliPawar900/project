package student.studentmanagementsystem.dao;

import java.time.LocalDate;
import java.util.List;
import  student.studentmanagementsystem.entity.Student;

public interface StudentDao{
	
	void addStudent(Student student);
	void saveStudent(Student student);
    List<Student> getAllStudents();
	//void deleteStudent(int id);
	//Student getStudentById(int id)
	Student getStudentById(int id);
	void deleteStudent(int id);
	void updateStudent(int studentId, String studentName, String fatherName, String lastName, String address,
			String city, String state, int pinCode, Long phoneNo, LocalDate DOB, int age);
}