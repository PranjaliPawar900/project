package student.studentmanagementsystem.dao;

import java.util.List;

import  student.studentmanagementsystem.entity.Faculty;

public interface FacultyDao {
	void addFaculty(Faculty faculty);
    Faculty getFaculty(int facultyId);
    List<Faculty> getAllFaculties();
    void updateFaculty(Faculty faculty);
    void deleteFaculty(int facultyId);
	void saveFaculty(Faculty faculty);
	Faculty getFacultyById(int id);
}
