package student.studentmanagementsystem.dao;

import student.studentmanagementsystem.entity.Course;
import student.studentmanagementsystem.entity.Department;

import java.util.List;
import java.util.Optional;

public interface CourseDao {

    // Method to save a new course to the database
    void saveCourse(Course course);

    // Method to get a course by its ID
    Course getCourseById(int courseId);

    // Method to get all courses
    List<Course> getAllCourses();

    // Method to update an existing course
    void updateCourse(Course course);

    // Method to delete a course by object reference
    void deleteCourse(Course course);

    // Method to delete a course by ID
   Course  deleteCourseById(int courseId);
   void updateCourse(int courseId, String courseName, int duration);
}
