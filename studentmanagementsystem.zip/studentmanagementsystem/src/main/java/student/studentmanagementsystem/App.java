package student.studentmanagementsystem;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import student.studentmanagementsystem.daoimpl.CourseDaoImpl;
import student.studentmanagementsystem.daoimpl.StudentDaoImpl;
import student.studentmanagementsystem.entity.Course;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.entity.Faculty;
import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.entity.Subject;
import student.studentmanagementsystem.services.AdminService;
import student.studentmanagementsystem.services.StudentService;
import student.studentmanagementsystem.services.SubjectService;
//import student.studentmanagementsystem.services.UserService;
import student.studentmanagementsystem.services.CourseService;
import student.studentmanagementsystem.services.FacultyService;
import student.studentmanagementsystem.services.DepartmentService;

public class App {

	public static void main(String args[]) {
		 	AdminService adminService = new AdminService();
	        StudentService studentService = new StudentService();
	        CourseService courseService =   new CourseService();
	        DepartmentService departmentService = new DepartmentService();
	        FacultyService facultyService = new FacultyService();
	        SubjectService subjectService = new SubjectService();
	        Scanner sc = new Scanner(System.in);

	        try {
	            if (!adminLogin(adminService, sc)) {
	                System.out.println("Exiting...");
	                return;
	            }

	            while (true) {
	                System.out.println("\n***** STUDENT MANAGEMENT SYSTEM *****");
	                System.out.println("1. Student ");
	                System.out.println("2. Course ");
	                System.out.println("3. Department ");
	                System.out.println("5. Subject ");
	                System.out.println("6. Exit");
	                System.out.print("Enter your choice: ");

	                int choice = getValidInteger(sc);
	                switch (choice) {
	                    case 1:
	                        studentMenu(sc, studentService);
	                        break;
	                    case 2:
	                        courseMenu(sc, courseService);
	                        break;
	                    case 3:
	                        departmentMenu(sc, departmentService);
	                        break;
	                    case 4:
	                        facultyMenu(sc, facultyService);
	                        break;
	                    case 5:
	                        subjectMenu(sc, subjectService);
	                        break;
	                    case 6:
	                        System.out.println("Exiting System...");
	                        return;
	                    default:
	                        System.out.println("Invalid choice! Please try again.");
	                }
	            }
	        } finally {
	            sc.close();
	        }
	    }

	    private static boolean adminLogin(AdminService adminService, Scanner sc) {
	        boolean isLoggedIn = false;

	        while (!isLoggedIn) {
	            System.out.print("Enter admin username: ");
	            String username = sc.next();

	            System.out.print("Enter the password: ");
	            String password = sc.next();

	            isLoggedIn = adminService.login(username, password);
	            if (!isLoggedIn) {
	                System.out.println("Invalid credentials. Type 'exit' to quit or try again.");
	                String choice = sc.next();
	                if (choice.equalsIgnoreCase("exit")) {
	                    return false;
	                }
	            }
	        }

	        System.out.println("Admin Login Successful! Welcome.");
	        return true;
	    }

	    private static int getValidInteger(Scanner sc) {
	        while (true) {
	            try {
	                return sc.nextInt();
	            } catch (Exception e) {
	                System.out.print("Invalid input. Please enter a valid number: ");
	                sc.nextLine(); // Clear invalid input
	            }
	        }
	    }
	    
	    // Method to get valid long input for phone number
	    private static long getValidLong(Scanner sc) {
	        while (true) {
	            try {
	                return sc.nextLong();
	            } catch (Exception e) {
	                System.out.print("Invalid input. Please enter a valid phone number: ");
	                sc.nextLine(); // Clear invalid input
	            }
	        }
	    }
	    // Method to parse and set DOB
	    private static LocalDate parseDateOfBirth(Scanner sc) {
	        while (true) {
	            try {
	                System.out.print("Enter Date of Birth (DD-MM-YYYY): ");
	                String dobString = sc.next();  // Input as a string (e.g., "04-01-2002")
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
	                return LocalDate.parse(dobString, formatter);
	            } catch (Exception e) {
	                System.out.println("Invalid Date format. Please use DD-MM-YYYY.");
	            }
	        }
	    }

	    // Student Management Menu
	    public static void studentMenu(Scanner sc, StudentService studentService) {
	        while (true) {
	            System.out.println("\nStudent Management Menu:");
	            System.out.println("1. Add Student");
	            System.out.println("2. View All Students");
	            System.out.println("3. Update Student");
	            System.out.println("4. Delete Student");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");

	            int choice = getValidInteger(sc);

	            switch (choice) {
	                case 1:
	                    Student newStudent = new Student();
	                    System.out.print("Enter Student Name: ");
	                    sc.nextLine();  // Consume leftover newline
	                    newStudent.setStudent_Name(sc.nextLine());
	                    System.out.print("Enter Father Name: ");
	                    newStudent.setFather_Name(sc.nextLine());
	                    System.out.print("Enter Last Name: ");
	                    newStudent.setLast_Name(sc.nextLine());
	                    System.out.print("Enter Address: ");
	                    newStudent.setAddress(sc.nextLine());
	                    System.out.print("Enter City: ");
	                    newStudent.setCity(sc.nextLine());
	                    System.out.print("Enter State: ");
	                    newStudent.setState(sc.nextLine());
	                    System.out.print("Enter Pincode: ");
	                    newStudent.setPin_code(getValidInteger(sc));
	                    System.out.print("Enter PhoneNo: ");
	                    newStudent.setPhone_no(getValidLong(sc));

	                    // Parse and set Date of Birth (DOB)
	                    newStudent.setDOB(parseDateOfBirth(sc));

	                    System.out.print("Enter Age: ");
	                    newStudent.setAge(getValidInteger(sc));
	             
	                    studentService.addStudent(newStudent);
	                    System.out.println("Student added successfully!");
	                    break;

	                case 2:
	                    // View all students
	                    List<Student> students = studentService.getAllStudents();
	                    if (students.isEmpty()) {
	                        System.out.println("No students found.");
	                    } else {
	                        students.forEach(System.out::println);
	                    }
	                    break;

	                case 3:
	                    // Update Student
	                    System.out.print("Enter Student ID to update: ");
	                    int studentId = getValidInteger(sc);
	                    System.out.print("Enter new Student Name: ");
	                    String studentName = sc.next();
	                    System.out.print("Enter new Father Name: ");
	                    String fatherName = sc.next();
	                    System.out.print("Enter new Last Name: ");
	                    String lastName = sc.next();
	                    System.out.print("Enter new Address: ");
	                    String address = sc.next();
	                    System.out.print("Enter new City: ");
	                    String city = sc.next();
	                    System.out.print("Enter new State: ");
	                    String state = sc.next();
	                    System.out.print("Enter new Pincode: ");
	                    int pinCode = sc.nextInt();
	                    System.out.print("Enter Phone_no: ");
	                    Long phoneNo = sc.nextLong();

	                    // Parse the Date of Birth (DOB) for update
	                    LocalDate dob = parseDateOfBirth(sc);

	                    System.out.print("Enter new Age: ");
	                    int age = sc.nextInt();
	                    //System.out.println("Enter Faculty Id:");
	                    //int faculty_id =sc.nextInt();

	                    // Assuming you have the updateStudent method in StudentService
	                    studentService.updateStudent(studentId, studentName, fatherName, lastName, address, city, state, pinCode, phoneNo, dob, age);
	                    System.out.println("Student updated successfully!");
	                    break;

	                case 4:
	                    // Delete Student
	                    System.out.print("Enter Student ID to delete: ");
	                    int deleteId = getValidInteger(sc);
	                    studentService.deleteStudent(deleteId);
	                    System.out.println("Student deleted successfully!");
	                    break;

	                case 5:
	                    // Exit the menu
	                    System.out.println("Exiting Student Management.");
	                    return;

	                default:
	                    System.out.println("Invalid choice! Please try again.");
	            }
	        }
	    }

		private static void courseMenu(Scanner sc, CourseService courseService) {
	    	while (true) {
	            System.out.println("\n----- Course Management System -----");
	            System.out.println("1. Add Course");
	            System.out.println("2. View All Courses");
	            System.out.println("3. Update Course");
	            System.out.println("4. Delete Course");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice: ");
	            
	            int choice = sc.nextInt();
	            sc.nextLine();  // Consume the newline after nextInt() to avoid skipping inputs

	            switch (choice) {
	                case 1:  // Add Course
	                    //System.out.print("Enter Course Id: ");
	                    //Long courseId = sc.nextLong();  // Assuming courseId is provided as part of the input
	                    //sc.nextLine();  // Consume newline

	                    System.out.print("Enter Course Name: ");
	                    String courseName = sc.nextLine();
	                    if (courseName == null || courseName.trim().isEmpty()) {
	                        System.out.println("Course name cannot be empty.");
	                        return;  // Exit or continue to next loop iteration
	                    }

	                    System.out.print("Enter Duration: ");
	                    int duration = sc.nextInt();
	                    sc.nextLine();  // Consume newline

	                    Course newCourse = new Course();
	                    newCourse.setCourseName(courseName);  // Ensure course name is set properly
	                    newCourse.setDuration(duration);//ensure course duration is set properly
	                    

	                    // Add course to the database via service
	                    courseService.addCourse(newCourse);
	                    break;
	                case 2:  // View All Courses
	                    List<Course> courses = courseService.getAllCourses();
	                    if (courses != null && !courses.isEmpty()) {
	                        courses.forEach(System.out::println);
	                    } else {
	                        System.out.println("No courses available.");
	                    }
	                    break;

	                case 3:  // Update Course
	                	 System.out.print("Enter Course ID to Update: ");
	                	    int courseId = sc.nextInt();
	                	    sc.nextLine(); // consume newline
	                	    System.out.print("Enter New Course Name: ");
	                	    String newCourseName = sc.nextLine();
	                	    System.out.print("Enter New Duration (in months): ");
	                	    int newDuration = sc.nextInt();

	                	    try {
	                	        Course updatedCourse = courseService.updateCourse(courseId, newCourseName, newDuration);
	                	        System.out.println("Course updated successfully: " + updatedCourse);
	                	    } catch (IllegalArgumentException e) {
	                	        System.out.println(e.getMessage());
	                	    }
                          break;
	                case 4:  // Delete Course
	                    System.out.print("Enter Course ID to Delete: ");
	                    int deleteId = sc.nextInt();
	                    courseService.deleteCourse(deleteId);
	                    break;

	                case 5:  // Exit
	                    System.out.println("Exiting the program.");
	                    return;

	                default:
	                    System.out.println("Invalid choice, please try again.");
	            }
	        }
	    }
	    public static void departmentMenu(Scanner sc, DepartmentService deptService) {
	    while (true) {
            System.out.println("\n----- Department Management System -----");
            System.out.println("1. Add Department");
            System.out.println("2. View All Departments");
            System.out.println("3. Update Department");
            System.out.println("4. Delete Department");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine();  // Consume the newline character

            switch (choice) {
                case 1:  // Add Department
                    System.out.print("Enter Department Name: ");
                    String departmentName = sc.nextLine();
                    Department newDepartment = new Department();
                    newDepartment.setdName(departmentName);
                    deptService.addDepartment(newDepartment);
                    System.out.println("Department added successfully!");
                    break;

                case 2:  // View All Departments
                    System.out.println("All Departments:");
                    List<Department> departments = deptService.getAllDepartments();
                    if (departments != null && !departments.isEmpty()) {
                        departments.forEach(System.out::println);
                    } else {
                        System.out.println("No departments available.");
                    }
                    break;

                case 3:  // Update Department
                    System.out.print("Enter Department ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine();  // Consume the newline character
                    Department existingDepartment = deptService.getDepartmentById(updateId);
                    if (existingDepartment != null) {
                        System.out.print("Enter new Department Name: ");
                        String updatedName = sc.nextLine();
                        existingDepartment.setdName(updatedName);
                        deptService.updateDepartment(existingDepartment);
                        System.out.println("Department updated successfully!");
                    } else {
                        System.out.println("Department with ID " + updateId + " not found!");
                    }
                    break;

                case 4:  // Delete Department
                    System.out.print("Enter Department ID to delete: ");
                    int deleteId = sc.nextInt();
                    sc.nextLine();  // Consume newline
                    Department departmentToDelete = deptService.getDepartmentById(deleteId);
                    if (departmentToDelete != null) {
                        deptService.deleteDepartment(deleteId);
                        System.out.println("Department deleted successfully!");
                    } else {
                        System.out.println("Department with ID " + deleteId + " not found!");
                    }
                    break;

                case 5:  // Exit
                    System.out.println("Exiting Department Management System.");
                    return;

                default:  // Invalid choice
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }


    public static void facultyMenu(Scanner sc, FacultyService facultyService) {

        while (true) {
            System.out.println("\n----- Faculty Management System -----");
            System.out.println("1. Add Faculty");
            System.out.println("2. View All Faculties");
            System.out.println("3. Update Faculty");
            System.out.println("4. Delete Faculty");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline character

            switch (choice) {
                case 1: // Add Faculty
                    System.out.print("Enter Faculty Name: ");
                    String facultyName = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = sc.nextDouble();
                    System.out.print("Enter Mobile Number: ");
                    long mobNo = sc.nextLong();
                    sc.nextLine(); // Consume newline

                    Faculty faculty = new Faculty();
                    faculty.setFacultyName(facultyName);
                    faculty.setSalary(salary);
                    faculty.setMobNo(mobNo);

                    // Assuming department is already created
                    //Department department = new Department("Computer Science");
                    //faculty.setDepartment(department);

                    facultyService.savaFaculty(faculty);
                    System.out.println("Faculty added successfully!");
                    break;

                case 2: // View All Faculties
                    List<Faculty> faculties = facultyService.getAllFaculties();
                    faculties.forEach(System.out::println);
                    break;

                case 3: // Update Faculty
                    System.out.print("Enter Faculty ID to update: ");
                    int facultyIdToUpdate = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    Faculty existingFaculty = facultyService.getFacultyById(facultyIdToUpdate);
                    if (existingFaculty != null) {
                        System.out.print("Enter new Faculty Name (leave blank to keep current): ");
                        String newName = sc.nextLine();
                        if (!newName.isEmpty()) {
                            existingFaculty.setFacultyName(newName);
                        }

                        System.out.print("Enter new Salary (leave blank to keep current): ");
                        String newSalary = sc.nextLine();
                        if (!newSalary.isEmpty()) {
                            existingFaculty.setSalary(Double.parseDouble(newSalary));
                        }

                        System.out.print("Enter new Mobile Number (leave blank to keep current): ");
                        String newMobileNo = sc.nextLine();
                        if (!newMobileNo.isEmpty()) {
                            existingFaculty.setMobNo(Long.parseLong(newMobileNo));
                        }

                        facultyService.addOrUpdateFaculty(existingFaculty);
                        System.out.println("Faculty updated successfully!");
                    } else {
                        System.out.println("Faculty with ID " + facultyIdToUpdate + " not found!");
                    }
                    break;

                case 4: // Delete Faculty
                    System.out.print("Enter Faculty ID to delete: ");
                    int facultyIdToDelete = sc.nextInt();
                    facultyService.deleteFaculty(facultyIdToDelete);
                    System.out.println("Faculty deleted successfully!");
                    break;

                case 5: //Exit
                    System.out.println("Exiting Faculty Management System.");
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    public static void subjectMenu(Scanner sc, SubjectService subjectService) {
        while (true) {
            System.out.println("\nSubject Management System");
            System.out.println("1. Add Subject");
            System.out.println("2. View All Subjects");
            System.out.println("3. Update Subject");
            System.out.println("4. Delete Subject");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline character

            switch (choice) {
                case 1: // Add Subject
                    try {
                        Subject subject = new Subject();
                        System.out.print("Enter Subject Name: ");
                        subject.setSub_Name(sc.nextLine());
                        subjectService.addSubject(subject);
                        System.out.println("Subject added successfully!");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 2: // View All Subjects
                    System.out.println("All Subjects:");
                    subjectService.getAllSubjects().forEach(System.out::println);
                    break;

                case 3: // Update Subject
                    try {
                        System.out.print("Enter Subject ID to update: ");
                        int updateId = sc.nextInt();
                        sc.nextLine(); // Consume newline character
                        Subject existingSubject = subjectService.getSubject(updateId);
                        if (existingSubject != null) {
                            System.out.print("Enter new Subject Name: ");
                            existingSubject.setSub_Name(sc.nextLine());
                            subjectService.updateSubject(existingSubject);
                            System.out.println("Subject updated successfully!");
                        } else {
                            System.out.println("Subject with ID " + updateId + " not found!");
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 4: // Delete Subject
                    System.out.print("Enter Subject ID to delete: ");
                    int deleteId = sc.nextInt();
                    Subject subjectToDelete = subjectService.getSubject(deleteId);
                    if (subjectToDelete != null) {
                        subjectService.deleteSubject(deleteId);
                        System.out.println("Subject deleted successfully!");
                    } else {
                        System.out.println("Subject with ID " + deleteId + " not found!");
                    }
                    break;

                case 5: // Exit
                    System.out.println("Exiting Subject Management System.");
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}  
