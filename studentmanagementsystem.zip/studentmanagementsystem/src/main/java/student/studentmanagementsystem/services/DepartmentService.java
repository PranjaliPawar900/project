package student.studentmanagementsystem.services;

import student.studentmanagementsystem.dao.DepartmentDao;
//import student.studentmanagementsystem.daoimpl.CourseDaoImpl;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.daoimpl.DepartmentDaoImpl; 

import java.util.List;

public class DepartmentService {

	private  DepartmentDao departmentDao;

    // Constructor-based Dependency Injection
    public DepartmentService() {
        this.departmentDao = new DepartmentDaoImpl();
    }	

    // Add a new department
    public void addDepartment(Department department) {
        try {
            validateDepartment(department);

            // Check for duplicate department
            if (departmentDao.existsByName(department.getdName())) {
                throw new IllegalStateException("Department with name '" + department.getdName() + "' already exists.");
            }

            departmentDao.saveDepartment(department);
            System.out.println("Department added successfully: " + department.getdName());
        } catch (Exception e) {
            System.err.println("Error adding department: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Get department by ID
    public Department getDepartmentById(int departmentId) {
        if (departmentId <= 0) {
            throw new IllegalArgumentException("Invalid department ID: " + departmentId);
        }

        try {
            Department department = departmentDao.getDepartmentById(departmentId);
            if (department == null) {
                System.out.println("No department found with ID: " + departmentId);
            }
            return department;
        } catch (Exception e) {
            System.err.println("Error fetching department by ID: " + e.getMessage());
            throw e;
        }
    }

    // Get all departments
    public List<Department> getAllDepartments() {
        try {
            return departmentDao.getAllDepartments();
        } catch (Exception e) {
            System.err.println("Error fetching all departments: " + e.getMessage());
            throw e;
        }
    }

    // Update department
    public void updateDepartment(Department department) {
        try {
            validateDepartment(department);

            if (department.getDepartmentId() <= 0) {
                throw new IllegalArgumentException("Invalid department ID for update.");
            }

            departmentDao.updateDepartment(department);
            System.out.println("Department updated successfully: " + department.getdName());
        } catch (Exception e) {
            System.err.println("Error updating department: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Delete department by ID
    public void deleteDepartment(int departmentId) {
        if (departmentId <= 0) {
            throw new IllegalArgumentException("Invalid department ID: " + departmentId);
        }

        try {
            departmentDao.deleteDepartment(departmentId);
            System.out.println("Department deleted successfully.");
        } catch (Exception e) {
            System.err.println("Error deleting department: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Get or create a department
    public Department getOrCreateDepartment(String departmentName) {
        if (departmentName == null || departmentName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be null or empty.");
        }

        try {
            // Check if department exists
            Department existingDepartment = departmentDao.getDepartmentByName(departmentName);
            if (existingDepartment != null) {
                System.out.println("Using existing department: " + existingDepartment.getdName());
                return existingDepartment;
            }

            // Create a new department if not found
            Department newDepartment = new Department();
            newDepartment.setdName(departmentName);
            departmentDao.saveDepartment(newDepartment);
            System.out.println("New department created: " + newDepartment.getdName());
            return newDepartment;
        } catch (Exception e) {
            System.err.println("Error in getOrCreateDepartment: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    // Validate department details
    private void validateDepartment(Department department) {
        if (department == null) {
            throw new IllegalArgumentException("Department cannot be null.");
        }

        if (department.getdName() == null || department.getdName().trim().isEmpty()) {
            throw new IllegalArgumentException("Department name is required.");
        }
    }
    
    }
    
