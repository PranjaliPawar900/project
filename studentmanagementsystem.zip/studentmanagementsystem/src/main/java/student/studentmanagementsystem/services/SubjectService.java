package student.studentmanagementsystem.services;

import java.util.List;

import student.studentmanagementsystem.dao.SubjectDao;
import student.studentmanagementsystem.daoimpl.SubjectDaoImpl;
import student.studentmanagementsystem.entity.Subject;

public class SubjectService {

    private SubjectDao subjectDao;

    // Constructor-based Dependency Injection
    public SubjectService() {
        subjectDao = new SubjectDaoImpl();  // Initialize the DAO
    }

    // Add a new Subject
    public void addSubject(Subject subject) {
        // Validate subject name before saving
        if (subject.getSub_Name() == null || subject.getSub_Name().trim().isEmpty()) {
            throw new IllegalArgumentException("Subject Name cannot be empty.");
        }
        subjectDao.saveSubject(subject);  // Save the subject to the database
    }

    // Get subject by ID
    public Subject getSubject(int id) {
        Subject subject = subjectDao.getSubjectById(id);  // Retrieve the subject by ID
        if (subject == null) {
            throw new IllegalArgumentException("Subject not found for ID: " + id);  // Handle if subject not found
        }
        return subject;
    }

    // Get all subjects
    public List<Subject> getAllSubjects() {
        return subjectDao.getAllSubjects();  // Retrieve the list of all subjects
    }

    // Update an existing subject
    public void updateSubject(Subject subject) {
        // Validate subject name before updating
        if (subject.getSub_Name() == null || subject.getSub_Name().trim().isEmpty()) {
            throw new IllegalArgumentException("Subject Name cannot be empty.");
        }
        subjectDao.updateSubject(subject);  // Update the subject
    }

    // Delete subject by ID
    public void deleteSubject(int id) {
        subjectDao.deleteSubject(id);  // Delete the subject by ID
    }
}
