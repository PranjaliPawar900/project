package student.studentmanagementsystem.services;

import student.studentmanagementsystem.dao.UserDao;
import student.studentmanagementsystem.daoimpl.UserDaoImpl;
import student.studentmanagementsystem.entity.User;

public class UserService {

	private UserDao userDao;

    public UserService() {
        this.userDao = new UserDaoImpl();
    }

    public boolean login(String username, String password) {
        return userDao.login(username, password);
    }

    public boolean register(String username, String password) {
        User user = new User(0, username, password);
        return userDao.register(user);
    }
}
