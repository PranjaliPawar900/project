package  student.studentmanagementsystem.services;

import java.util.List;

import  student.studentmanagementsystem.dao.FacultyDao;
import student.studentmanagementsystem.daoimpl.FacultyDaoImpl;
import  student.studentmanagementsystem.entity.Faculty;

public class FacultyService {
	 private FacultyDao facultyDao;

	    // Constructor to inject FacultyDao
	    public FacultyService() {
	    	this.facultyDao = new FacultyDaoImpl();//intialize daoimpl
	    }

	    public void addOrUpdateFaculty(Faculty faculty) {
	        // Validate the input
	        if (faculty == null) {
	            throw new IllegalArgumentException("Faculty cannot be null");
	        }

	        if (faculty.getFacultyName() == null || faculty.getFacultyName().trim().isEmpty()) {
	            throw new IllegalArgumentException("Faculty name cannot be null or empty");
	        }

	        if (faculty.getSalary() <= 0) {
	            throw new IllegalArgumentException("Faculty salary must be greater than zero");
	        }

	        if (String.valueOf(faculty.getMobNo()).length() != 10) {
	            throw new IllegalArgumentException("Mobile number must be exactly 10 digits");
	        }

	        // Call the DAO method to save or update
	        facultyDao.saveFaculty(faculty);
	    }

	    public Faculty getFacultyById(int id) {
	        // Validate the input ID
	        if (id <= 0) {
	            throw new IllegalArgumentException("Invalid faculty ID");
	        }

	        Faculty faculty = facultyDao.getFacultyById(id);
	        if (faculty == null) {
	            throw new RuntimeException("Faculty with ID " + id + " not found");
	        }

	        return faculty;
	    }

	    public List<Faculty> getAllFaculties() {
	        List<Faculty> faculties = facultyDao.getAllFaculties();
	        if (faculties == null || faculties.isEmpty()) {
	            throw new RuntimeException("No faculties found in the database");
	        }

	        return faculties;
	    }

	    public void deleteFaculty(int id) {
	        // Validate the input ID
	        if (id <= 0) {
	            throw new IllegalArgumentException("Invalid faculty ID");
	        }

	        Faculty faculty = facultyDao.getFacultyById(id);
	        if (faculty == null) {
	            throw new RuntimeException("Faculty with ID " + id + " does not exist");
	        }

	        // Call the DAO to delete the faculty
	        facultyDao.deleteFaculty(id);
	        System.out.println("Faculty with ID " + id + " deleted successfully");
	    }

		public void savaFaculty(Faculty faculty) {
		    if (faculty == null) {
		        throw new IllegalArgumentException("Faculty cannot be null");
		    }

		    // Validate faculty details
		    validateFacultyDetails(faculty);

		    // Attempt to save the faculty record
		    try {
		        // Assuming facultyDao.saveFaculty() method is already handling transaction management
		        facultyDao.saveFaculty(faculty);
		        System.out.println("Faculty saved successfully!");
		    } catch (Exception e) {
		        // Log the exception and throw a custom exception
		        System.err.println("Error occurred while saving faculty: " + e.getMessage());
		        //throw new RuntimeException("An error occurred while saving the faculty record. Please try again.", e);
		    }
		}
		
		private void validateFacultyDetails(Faculty faculty) {
	        if (faculty.getFacultyName() == null || faculty.getFacultyName().trim().isEmpty()) {
	            throw new IllegalArgumentException("Faculty name cannot be null or empty");
	        }

	        if (faculty.getSalary() <= 0) {
	            throw new IllegalArgumentException("Faculty salary must be greater than zero");
	        }

	        if (String.valueOf(faculty.getMobNo()).length() != 10) {
	            throw new IllegalArgumentException("Mobile number must be exactly 10 digits");
	        }
	    }
}
