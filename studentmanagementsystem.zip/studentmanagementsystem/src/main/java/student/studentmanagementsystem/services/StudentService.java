package student.studentmanagementsystem.services;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hibernate.Session;
import org.hibernate.query.Query;

import student.studentmanagementsystem.dao.StudentDao;
import student.studentmanagementsystem.daoimpl.StudentDaoImpl;
import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.util.HibernateUtil;

public class StudentService {

    private StudentDao studentDao;

    // Constructor to initialize the StudentDao instance
    public StudentService() {
        studentDao = new StudentDaoImpl();  // Initialize the DAO
    }

    // Method to add a new student
    public void addStudent(Student student) {
        // Validate student before adding
        if (student == null) {
            System.out.println("Failed to add student. Student object is null.");
            return;
        }

        if (student.getStudent_Name() == null || student.getStudent_Name().isEmpty()) {
            System.out.println("Failed to add student. Student name is required.");
            return;
        }

        if (student.getFather_Name() == null || student.getFather_Name().isEmpty()) {
            System.out.println("Failed to add student. Father's name is required.");
            return;
        }

        if (student.getLast_Name() == null || student.getLast_Name().isEmpty()) {
            System.out.println("Failed to add student. Last name is required.");
            return;
        }

        if (student.getDOB() == null) {
            System.out.println("Failed to add student. Date of birth is required.");
            return;
        }

        if (student.getAge() <= 0) {
            System.out.println("Failed to add student. Age must be greater than 0.");
            return;
        }

        if (!isValidPhoneNumber(student.getPhone_no())) {
            System.out.println("Failed to add student. Invalid phone number.");
            return;
        }

        // If age is not provided, calculate it from the date of birth
        if (student.getAge() == 0) {
            student.setAge(calculateAge(student.getDOB()));
        }

        // If all basic checks pass, save the student
        studentDao.saveStudent(student);  // Save student to database
        System.out.println("Student added successfully.");
    }

    // Method to get a student by ID
    public Student getStudent(int id) {
        // Fetch student by ID from the database
        return studentDao.getStudentById(id);
    }

    // Method to get all students
    public List<Student> getAllStudents() {
        // Get the session from HibernateUtil
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Student";
            Query<Student> query = session.createQuery(hql, Student.class);
            return query.list();
        }
    }

    // Method to update an existing student
    public void updateStudent(int studentId, String studentName, String fatherName, String lastName,
                              String address, String city, String state, int pinCode, Long phoneNo, LocalDate dob, int age) {
        // Validate the input parameters
        if (studentId <= 0) {
            System.out.println("Invalid student ID for updating the student.");
            return;
        }

        if (studentName == null || studentName.isEmpty()) {
            System.out.println("Student name is required.");
            return;
        }

        if (fatherName == null || fatherName.isEmpty()) {
            System.out.println("Father's name is required.");
            return;
        }

        if (lastName == null || lastName.isEmpty()) {
            System.out.println("Last name is required.");
            return;
        }

        if (address == null || address.isEmpty()) {
            System.out.println("Address is required.");
            return;
        }

        if (city == null || city.isEmpty()) {
            System.out.println("City is required.");
            return;
        }

        if (state == null || state.isEmpty()) {
            System.out.println("State is required.");
            return;
        }

        if (pinCode <= 0) {
            System.out.println("Invalid pin code.");
            return;
        }

        if (!isValidPhoneNumber(phoneNo)) {
            System.out.println("Invalid phone number.");
            return;
        }

        if (dob == null || dob.isAfter(LocalDate.now())) {
            System.out.println("Invalid date of birth.");
            return;
        }

        if (age < 18 || age > 100) {
            System.out.println("Age must be between 18 and 100.");
            return;
        }

        // Automatically calculate age based on DOB if not provided manually
        if (age == 0) {
            age = calculateAge(dob);
        }

        // If all validation checks pass, proceed with the update
        studentDao.updateStudent(studentId, studentName, fatherName, lastName, address, city, state, pinCode, phoneNo, dob, age);
        System.out.println("Student updated successfully.");
    }

    // Method to delete a student by ID
    public void deleteStudent(int deleteId) {
        // Ensure that the student ID is valid
        if (deleteId <= 0) {
            System.out.println("Invalid student ID for deletion.");
            return;
        }

        studentDao.deleteStudent(deleteId);  // Delete student from the database
        System.out.println("Student deleted successfully.");
    }

    // Method to search students by name or other attributes (e.g., city, state)
   /* public List<Student> searchStudents(String searchTerm) {
        // Perform search using DAO methods based on the term provided
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            System.out.println("Search term is empty. Cannot perform search.");
            return null;
        }

        List<Student> students = studentDao.searchStudents(searchTerm);
        if (students.isEmpty()) {
            System.out.println("No students found matching the search term.");
        }
        return students;
    }*/

    // Method to calculate age based on DOB
    private int calculateAge(LocalDate dob) {
        if (dob == null) {
            return 0;
        }
        return Period.between(dob, LocalDate.now()).getYears();
    }

    // Method to validate phone number format (e.g., 10-digit number)
    private boolean isValidPhoneNumber(Long phoneNo) {
        if (phoneNo == null) {
            return false;
        }

        String phoneStr = phoneNo.toString();
        String phonePattern = "^[0-9]{10}$";  // Simple pattern for 10-digit phone numbers

        Pattern pattern = Pattern.compile(phonePattern);
        Matcher matcher = pattern.matcher(phoneStr);

        return matcher.matches();
    }
}
