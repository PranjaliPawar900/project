package  student.studentmanagementsystem.services;

import org.hibernate.Session;

import  student.studentmanagementsystem.util.HibernateUtil;
import  student.studentmanagementsystem.entity.User;


public class LoginService {
	   public User login(String username, String password) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        User user = session.createQuery("from User where username = :username and password = :password", User.class)
	                .setParameter("username", username)
	                .setParameter("password", password)
	                .uniqueResult();
	        session.close();
	        return user;
	    }
}
