package student.studentmanagementsystem.services;

import student.studentmanagementsystem.dao.CourseDao;
import student.studentmanagementsystem.dao.DepartmentDao;
//import student.studentmanagementsystem.dao.DepartmentDao;
import student.studentmanagementsystem.daoimpl.CourseDaoImpl;
import student.studentmanagementsystem.entity.Course;
//import student.studentmanagementsystem.entity.Department;
//import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.util.HibernateUtil;

import java.util.List;
import java.util.Optional;

import org.hibernate.Session;

public class CourseService {

	private CourseDao courseDao;

    public CourseService() {
       courseDao = new CourseDaoImpl();
    }

    public void addCourse(Course course) {
    	    // Validate the course before proceeding
    	 try {
    	        validateCourse(course);
    	    } catch (IllegalArgumentException e) {
    	        // Log the validation error
    	        System.out.println("Error: " + e.getMessage());
    	        return;  // Return early if validation fails
    	    }

    	    // Proceed with saving the course
    	    try {
    	        courseDao.saveCourse(course);
    	        System.out.println("Course added successfully: " + course.getCourseName());
    	    } catch (Exception e) {
    	        // Log the error in saving the course
    	        System.err.println("Error saving course: " + e.getMessage());
    	        // Optionally, rethrow or handle the exception depending on the requirement
    	        throw new RuntimeException("Error saving course", e);
    	    }
    	}

    	private void validateCourse(Course course) {
    	    // Check if the course is null
    	    if (course == null) {
    	        throw new IllegalArgumentException("Course object cannot be null.");
    	    }

    	    // Validate course name
    	    if (course.getCourseName() == null || course.getCourseName().trim().isEmpty()) {
    	        throw new IllegalArgumentException("Course name cannot be empty or contain only whitespace.");
    	    }

    	    // Validate course duration
    	    if (course.getDuration() <= 0) {
    	        throw new IllegalArgumentException("Duration must be greater than 0.");
    	    }

    	    // Additional validation checks (if needed)
    	    // For example: Checking for specific constraints or regex on course name
    	    if (course.getCourseName().length() > 100) {
    	        throw new IllegalArgumentException("Course name cannot exceed 100 characters.");
    	    }

    	    // You can add more validation rules here if required
    	    // Example: If the course duration exceeds some limit
    	    if (course.getDuration() > 120) {
    	        throw new IllegalArgumentException("Course duration cannot exceed 120 months.");
    	    }
    }

    public List<Course> getAllCourses() {
        return courseDao.getAllCourses();
    }

    public void updateCourse(Course course) {
        updateCourse(course);
        courseDao.updateCourse(course);
    }


    // Update an existing course
    public Course updateCourse(int courseId, String courseName, int duration) {
        // First, fetch the course to be updated
    	   // Fetch the course to be updated
        Course course = courseDao.deleteCourseById(courseId); // Assuming this method fetches the course

        if (course != null) {
            // Set the new values
            course.setCourseName(courseName);
            course.setDuration(duration);

            // Update the course using DAO
            courseDao.updateCourse(courseId, courseName, duration);

            // Return the updated course object
            return course;
        } else {
            // If course not found, throw an exception or return null
            throw new IllegalArgumentException("Course not found with ID: " + courseId);
        }
    }

    // Delete a course by its ID
    public void deleteCourse(int courseId) {
    	  // Validate course ID
        if (isValidId(courseId)) {
            // Ensure getCourses(courseId) returns Optional
            Optional<Course> courseOptional = getCourses(courseId);

            // Check if the course is present in the Optional
            if (courseOptional.isPresent()) {
                try {
                    // Proceed to delete the course
                    courseDao.deleteCourse(courseOptional.get());
                    System.out.println("Course deleted successfully.");
                } catch (Exception e) {
                    // Log error in case of failure
                    System.err.println("Failed to delete course: " + e.getMessage());
                }
            } else {
                // Handle case where the course is not found
                System.err.println("Course with ID " + courseId + " not found.");
            }
        } else {
            // Invalid ID handling
            System.err.println("Invalid Course ID: " + courseId);
        }
    }

	// Validate course entity before saving or updating
    /*private boolean isValidCourse(Course course) {
        if (course == null) {
            System.err.println("Course cannot be null.");
            return false;
        }
        if (course.getCourseName() == null || course.getCourseName().trim().isEmpty()) {
            System.out.println("Course name is required.");
            return false;
        }
        if (course.getDuration() <= 0) {
            System.out.println("Duration must be greater than 0.");
            return false;
        }
        //if (course.getDepartment() == null || course.getDepartment().getdName() == null || course.getDepartment().getdName().trim().isEmpty()) {
            //System.err.println("Department is required.");
            //return false;
        //}
        return true;
    }*/

	private Optional<Course> getCourses(int courseId) {
		// Validate the course ID to ensure it is valid before querying
	    if (courseId <= 0) {
	        System.err.println("Invalid Course ID: " + courseId + ". ID must be greater than 0.");
	        return Optional.empty(); // Return empty Optional for invalid ID
	    }

	    // Open a Hibernate session
	    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	        // Retrieve the course by its ID using Hibernate's session.get() method
	        Course course = session.get(Course.class, courseId);

	        // If the course is found, return it wrapped in an Optional
	        return Optional.ofNullable(course);  // Returns an empty Optional if course is null
	    } catch (Exception e) {
	        // Log any errors and return an empty Optional
	        e.printStackTrace();
	        System.err.println("Error retrieving course with ID " + courseId + ": " + e.getMessage());
	        return Optional.empty();  // Return empty Optional in case of an error
	    }
	}

	// Validate ID for operations
    private boolean isValidId(int id) {
    	  if (id <= 0) {
    	        System.err.println("Invalid ID: " + id + ". ID must be greater than 0.");
    	        return false;
    	    }
    	    return true;
    }
}
