package student.studentmanagementsystem.services;

import student.studentmanagementsystem.dao.AdminDao;
import student.studentmanagementsystem.daoimpl.AdminDaoImpl;

public class AdminService {

    private AdminDao adminDao;

    // Constructor to initialize AdminDao
    public AdminService() {
        this.adminDao = new AdminDaoImpl(); // Ensuring adminDao is initialized here
    }

    // Login method that uses adminDao to check the credentials
    public boolean login(String username, String password) {
        if (this.adminDao == null) {
            System.out.println("Error: AdminDao is not initialized.");
            return false;
        }

        // Perform the login operation using adminDao
        return this.adminDao.getAdminByUsername(username, password) != null;
    }
}
