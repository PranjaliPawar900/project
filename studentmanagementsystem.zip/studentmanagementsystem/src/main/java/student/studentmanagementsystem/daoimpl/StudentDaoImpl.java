package student.studentmanagementsystem.daoimpl;

import java.time.LocalDate;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import student.studentmanagementsystem.dao.StudentDao;
import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.util.HibernateUtil;

public class StudentDaoImpl implements StudentDao {

    // Declare SessionFactory field
	 private SessionFactory sessionFactory;

	    public StudentDaoImpl() {
	        this.sessionFactory = HibernateUtil.getSessionFactory();
	        if (this.sessionFactory == null) {
	            throw new RuntimeException("SessionFactory is not initialized correctly.");
	        }
	    }

	    @Override
	    public void addStudent(Student student) {
	        if (student == null) {
	            System.out.println("Student cannot be null.");
	            return;
	        }

	        try (Session session = sessionFactory.openSession()) {
	            Transaction tx = session.beginTransaction();
	            session.save(student);
	            tx.commit();
	            System.out.println("Student added successfully.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public Student getStudentById(int id) {
	        try (Session session = sessionFactory.openSession()) {
	            return session.get(Student.class, id);
	        }
	    }

	    @Override
	    public List<Student> getAllStudents() {
	        try (Session session = sessionFactory.openSession()) {
	            return session.createQuery("from Student", Student.class).list();
	        }
	    }

	    @Override
	    public void saveStudent(Student student) {
	        try (Session session = sessionFactory.openSession()) {
	            Transaction tx = session.beginTransaction();
	            session.save(student);
	            tx.commit();
	            System.out.println("Student saved successfully.");
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void deleteStudent(int id) {
	        try (Session session = sessionFactory.openSession()) {
	            Transaction tx = session.beginTransaction();
	            Student student = session.get(Student.class, id);
	            if (student != null) {
	                session.delete(student);
	            }
	            tx.commit();
	        }
	    }

	    @Override
	    public void updateStudent(int studentId, String studentName, String fatherName, String lastName,
	            String address, String city, String state, int pinCode, Long phoneNo, LocalDate DOB, int age) {
	        try (Session session = sessionFactory.openSession()) {
	            Transaction tx = session.beginTransaction();
	            Student student = session.get(Student.class, studentId);
	            if (student != null) {
	                student.setStudent_Name(studentName);
	                student.setFather_Name(fatherName);
	                student.setLast_Name(lastName);
	                student.setAddress(address);
	                student.setCity(city);
	                student.setState(state);
	                student.setPin_code(pinCode);
	                student.setPhone_no(phoneNo);
	                student.setDOB(DOB);
	                student.setAge(age);
	                //student.setFaculty(faculty_id);
	                session.update(student);
	                tx.commit();
	                System.out.println("Student updated successfully.");
	            } else {
	                System.out.println("Student not found with ID: " + studentId);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
}
