package student.studentmanagementsystem.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import student.studentmanagementsystem.dao.FacultyDao;
import student.studentmanagementsystem.entity.Faculty;

public class FacultyDaoImpl implements FacultyDao {

	private SessionFactory sessionFactory;

	 // Constructor to initialize SessionFactory
    public FacultyDaoImpl() {
        try {
            this.sessionFactory = new Configuration().configure().buildSessionFactory();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize Hibernate SessionFactory.", e);
        }
    }

    @Override
    public void addFaculty(Faculty faculty) {
        if (faculty == null) {
            throw new IllegalArgumentException("Faculty object cannot be null.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(faculty);
            transaction.commit();
            System.out.println("Faculty added successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while adding faculty.", e);
        }
    }

    @Override
    public Faculty getFaculty(int facultyId) {
        if (facultyId <= 0) {
            throw new IllegalArgumentException("Faculty ID must be greater than zero.");
        }

        try (Session session = sessionFactory.openSession()) {
            return session.get(Faculty.class, facultyId);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while retrieving faculty with ID " + facultyId, e);
        }
    }

    @Override
    public List<Faculty> getAllFaculties() {
        try (Session session = sessionFactory.openSession()) {
            Query<Faculty> query = session.createQuery("from Faculty", Faculty.class);
            return query.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while retrieving all faculties.", e);
        }
    }

    @Override
    public void updateFaculty(Faculty faculty) {
        if (faculty == null || faculty.getFacultyId() <= 0) {
            throw new IllegalArgumentException("Faculty object is invalid for update.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.update(faculty);
            transaction.commit();
            System.out.println("Faculty updated successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while updating faculty.", e);
        }
    }

    @Override
    public void deleteFaculty(int facultyId) {
        if (facultyId <= 0) {
            throw new IllegalArgumentException("Faculty ID must be greater than zero.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            Faculty faculty = session.get(Faculty.class, facultyId);

            if (faculty != null) {
                session.delete(faculty);
                System.out.println("Faculty with ID " + facultyId + " deleted successfully!");
            } else {
                System.out.println("Faculty with ID " + facultyId + " not found.");
            }

            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while deleting faculty.", e);
        }
    }

    @Override
    public void saveFaculty(Faculty faculty) {
        if (faculty == null) {
            throw new IllegalArgumentException("Faculty object cannot be null.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();

            if (faculty.getFacultyId() > 0) {
                session.update(faculty);
                System.out.println("Faculty updated successfully!");
            } else {
                session.save(faculty);
                System.out.println("Faculty added successfully!");
            }

            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while saving faculty.", e);
        }
    }

    @Override
    public Faculty getFacultyById(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Faculty ID must be greater than zero.");
        }

        try (Session session = sessionFactory.openSession()) {
            Faculty faculty = session.get(Faculty.class, id);
            if (faculty == null) {
                System.out.println("Faculty with ID " + id + " not found.");
            }
            return faculty;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Error occurred while retrieving faculty by ID.", e);
        }
    }
}
