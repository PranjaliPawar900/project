package student.studentmanagementsystem.daoimpl;

import org.hibernate.Session;
import org.hibernate.Transaction;
import student.studentmanagementsystem.dao.CourseDao;
import student.studentmanagementsystem.entity.Course;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.util.HibernateUtil;

import java.util.List;
import java.util.Optional;

public class CourseDaoImpl implements CourseDao {
	private Session SessionFactory;
     //save method for course
	 @Override
	    public void saveCourse(Course course) {
		  if (course == null) {
	            System.out.println("Cannot save a null course.");
	            return;
	        }

	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Transaction transaction = session.beginTransaction();
	            session.save(course);
	            transaction.commit();
	            System.out.println("Course saved successfully: " + course.getCourseName());
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error while saving course: " + e.getMessage());
	        }
	    }

	    public Course getCourseById(Long courseId) {
	        if (courseId == null) {
	            System.out.println("Course ID cannot be null.");
	            return null;
	        }

	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Course course = session.get(Course.class, courseId);
	            if (course == null) {
	                System.out.println("No course found with ID: " + courseId);
	            }
	            return course;
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error fetching course by ID: " + e.getMessage());
	            return null;
	        }
	    }

	    @Override
	    public List<Course> getAllCourses() {
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            List<Course> courses = session.createQuery("FROM Course", Course.class).list();
	            if (courses.isEmpty()) {
	                System.out.println("No courses available.");
	            }
	            return courses;
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error fetching all courses: " + e.getMessage());
	            return null;
	        }
	    }

	    @Override
	    public void updateCourse(Course course) {
	        if (course == null || course.getCourseId() == 0) {
	            System.out.println("Invalid course or course ID.");
	            return;
	        }

	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Transaction transaction = session.beginTransaction();
	            session.update(course);
	            transaction.commit();
	            System.out.println("Course updated successfully: " + course.getCourseName());
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error updating course: " + e.getMessage());
	        }
	    }

	    @Override
	    public void deleteCourse(Course course) {
	        if (course == null || course.getCourseId() == 0) {
	            System.out.println("Invalid course or course ID.");
	            return;
	        }

	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Transaction transaction = session.beginTransaction();
	            session.delete(course);
	            transaction.commit();
	            System.out.println("Course deleted successfully: " + course.getCourseName());
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error deleting course: " + e.getMessage());
	        }
	    }

	    @Override
	   public Course deleteCourseById(int courseId) {
	    	  if (courseId <= 0) {
	    	        System.out.println("Course ID must be greater than 0.");
	    	        return null; // Return null for invalid course ID
	    	    }

	    	    Course deletedCourse = null; // Variable to hold the course to be returned

	    	    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	    	        Transaction transaction = session.beginTransaction();
	    	        deletedCourse = session.get(Course.class, courseId);

	    	        if (deletedCourse != null) {
	    	            session.delete(deletedCourse);
	    	            transaction.commit();
	    	            System.out.println("Course deleted successfully with ID: " + courseId);
	    	        } else {
	    	            System.out.println("No course found with ID: " + courseId);
	    	        }
	    	    } catch (Exception e) {
	    	        e.printStackTrace();
	    	        System.out.println("Error deleting course by ID: " + e.getMessage());
	    	    }

	    	    return deletedCourse; // Return the deleted course or null if not found

	    }
	    public void updateCourse(int courseId, String courseName, int duration) {
	        if (courseId <= 0) {
	            System.out.println("Invalid course ID.");
	            return;
	        }

	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            Transaction transaction = session.beginTransaction();
	            Course course = session.get(Course.class, courseId);

	            if (course == null) {
	                System.out.println("No course found with ID: " + courseId);
	                transaction.rollback();
	                return;
	            }

	            // Update course fields
	            course.setCourseName(courseName);
	            course.setDuration(duration);

	            session.update(course);
	            transaction.commit();
	            System.out.println("Course updated successfully: " + courseName);
	        } catch (Exception e) {
	            e.printStackTrace();
	            System.out.println("Error updating course: " + e.getMessage());
	        }
	    }

		@Override
		public Course getCourseById(int courseId) {
			        // Validate the input ID
			        if (courseId <= 0) {
			            throw new IllegalArgumentException("Course ID must be greater than zero.");
			        }

			        // Initialize course object
			        Course course = null;

			        // Open a Hibernate session
			        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			            // Start a transaction (not mandatory here but good practice for data retrieval)
			            // Transaction transaction = session.beginTransaction();

			            // Retrieve the course by its ID
			            course = session.get(Course.class, courseId);

			            // If course is not found, it will return null
			            if (course == null) {
			                System.out.println("Course with ID " + courseId + " not found.");
			            }

			            // Commit transaction if any changes were made (only necessary for update/delete)
			            // transaction.commit();
			        } catch (Exception e) {
			            e.printStackTrace();
			            System.err.println("Error retrieving course with ID " + courseId + ": " + e.getMessage());
			        }

			        // Return the course object (it could be null if not found)
			        return course;
		}
	    

}
