package student.studentmanagementsystem.daoimpl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import student.studentmanagementsystem.dao.SubjectDao;
import student.studentmanagementsystem.entity.Subject;

public class SubjectDaoImpl implements SubjectDao {

    private static SessionFactory sessionFactory;  // Use static SessionFactory for efficient session management

    // Static block for initializing SessionFactory once
    static {
        sessionFactory = new Configuration()
            .configure("hibernate.cfg.xml")  // Load Hibernate config
            .addAnnotatedClass(Subject.class)  // Add Subject class
            .buildSessionFactory();  // Build the sessionFactory once
    }

    @Override
    public void saveSubject(Subject subject) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.save(subject);  // Save the subject to the database
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();  // Rollback if any exception occurs
            e.printStackTrace();
        }
    }

    @Override
    public Subject getSubjectById(int id) {
        try (Session session = sessionFactory.openSession()) {
            return session.get(Subject.class, id);  // Fetch the subject by ID
        } catch (Exception e) {
            e.printStackTrace();
            return null;  // Return null if subject is not found
        }
    }

    @Override
    public List<Subject> getAllSubjects() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("from Subject", Subject.class).list();  // Fetch all subjects
        } catch (Exception e) {
            e.printStackTrace();
            return null;  // Return null if an error occurs
        }
    }

    @Override
    public void updateSubject(Subject subject) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            session.update(subject);  // Update subject information
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();  // Rollback if any exception occurs
            e.printStackTrace();
        }
    }

    @Override
    public void deleteSubject(int id) {
        Transaction tx = null;
        try (Session session = sessionFactory.openSession()) {
            tx = session.beginTransaction();
            Subject subject = session.get(Subject.class, id);  // Fetch the subject to delete
            if (subject != null) {
                session.delete(subject);  // Delete the subject
            }
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();  // Rollback if any exception occurs
            e.printStackTrace();
        }
    }

    // Close the sessionFactory when the application is done
    public static void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
