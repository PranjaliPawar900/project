package student.studentmanagementsystem.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import student.studentmanagementsystem.dao.DepartmentDao;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.services.DepartmentService;
import student.studentmanagementsystem.util.HibernateUtil;

import java.util.List;

public class DepartmentDaoImpl implements DepartmentDao {
	private final SessionFactory sessionFactory;

    // Constructor to initialize sessionFactory
    public DepartmentDaoImpl() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
        if (this.sessionFactory == null) {
            throw new RuntimeException("SessionFactory is not initialized correctly.");
        }
    }

    @Override
    public void addDepartment(Department department) {
        if (department == null) {
            throw new IllegalArgumentException("Department cannot be null.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            try {
                session.save(department); // Save the department entity
                tx.commit();
                System.out.println("Department added successfully.");
            } catch (Exception e) {
                tx.rollback();
                System.err.println("Error adding department: " + e.getMessage());
                throw e; // Rethrow exception to handle at a higher level
            }
        }
    }

    @Override
    public Department getDepartmentById(int departmentId) {
        if (departmentId <= 0) {
            throw new IllegalArgumentException("Invalid department ID: " + departmentId);
        }

        try (Session session = sessionFactory.openSession()) {
            return session.get(Department.class, departmentId);
        } catch (Exception e) {
            System.err.println("Error fetching department by ID: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public List<Department> getAllDepartments() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Department", Department.class).list();
        } catch (Exception e) {
            System.err.println("Error fetching all departments: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public void updateDepartment(Department department) {
        if (department == null || department.getDepartmentId() <= 0) {
            throw new IllegalArgumentException("Invalid department details for update.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            try {
                Department existingDepartment = session.get(Department.class, department.getDepartmentId());
                if (existingDepartment == null) {
                    throw new IllegalStateException("Department not found with ID: " + department.getDepartmentId());
                }

                existingDepartment.setdName(department.getdName()); // Update department name
                session.update(existingDepartment);
                tx.commit();
                System.out.println("Department updated successfully.");
            } catch (Exception e) {
                tx.rollback();
                System.err.println("Error updating department: " + e.getMessage());
                throw e;
            }
        }
    }

    @Override
    public void deleteDepartment(int departmentId) {
        if (departmentId <= 0) {
            throw new IllegalArgumentException("Invalid department ID: " + departmentId);
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            try {
                Department department = session.get(Department.class, departmentId);
                if (department == null) {
                    throw new IllegalStateException("Department not found with ID: " + departmentId);
                }

                session.delete(department);
                tx.commit();
                System.out.println("Department deleted successfully.");
            } catch (Exception e) {
                tx.rollback();
                System.err.println("Error deleting department: " + e.getMessage());
                throw e;
            }
        }
    }

    @Override
    public void saveDepartment(Department department) {
        if (department == null) {
            throw new IllegalArgumentException("Department cannot be null.");
        }

        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            try {
                session.saveOrUpdate(department);
                tx.commit();
                System.out.println("Department saved successfully.");
            } catch (Exception e) {
                tx.rollback();
                System.err.println("Error saving department: " + e.getMessage());
                throw e;
            }
        }
    }

    @Override
    public Department getDepartmentByName(String departmentName) {
        if (departmentName == null || departmentName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be null or empty.");
        }

        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Department WHERE dName = :dName", Department.class)
                    .setParameter("dName", departmentName)
                    .uniqueResult();
        } catch (Exception e) {
            System.err.println("Error fetching department by name: " + e.getMessage());
            throw e;
        }
    }

    @Override
    public boolean existsByName(String departmentName) {
        if (departmentName == null || departmentName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be null or empty.");
        }

        try (Session session = sessionFactory.openSession()) {
            Long count = session.createQuery("SELECT COUNT(d) FROM Department d WHERE d.dName = :dName", Long.class)
                    .setParameter("dName", departmentName)
                    .uniqueResult();
            return count != null && count > 0;
        } catch (Exception e) {
            System.err.println("Error checking if department exists by name: " + e.getMessage());
            throw e;
        }
    }
	   
	}
