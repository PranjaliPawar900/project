package student.studentmanagementsystem.daoimpl;

import student.studentmanagementsystem.dao.AdminDao;
import student.studentmanagementsystem.entity.Admin;

import java.util.HashMap;
import java.util.Map;

public class AdminDaoImpl implements AdminDao {

    // Simulating an in-memory data store for admin data
    private static final Map<String, Admin> admins = new HashMap<>();

    static {
        // Adding a dummy admin for testing
        Admin admin = new Admin("pranjali", "1234");
        admins.put(admin.getUsername(), admin);
    }

    @Override
    public Admin getAdminByUsername(String username, String password) {
        Admin admin = admins.get(username);
        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }
        return null; // Return null if no admin found or password mismatch
    }
}
