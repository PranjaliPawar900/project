package student.studentmanagementsystem.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import student.studentmanagementsystem.dao.UserDao;
import student.studentmanagementsystem.entity.User;
import student.studentmanagementsystem.util.HibernateUtil;  // Utility class to manage Hibernate session factory

public class UserDaoImpl implements UserDao {


    private SessionFactory sessionFactory;

    public UserDaoImpl() {
        this.sessionFactory = HibernateUtil.getSessionFactory();
    }

    @Override
    public boolean login(String username, String password) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        boolean loginSuccessful = false;

        try {
            transaction = session.beginTransaction();
            String hql = "FROM User WHERE username = :username AND password = :password";
            Query<User> query = session.createQuery(hql, User.class);
            query.setParameter("username", username);
            query.setParameter("password", password);
            User user = query.uniqueResult();

            if (user != null) {
                loginSuccessful = true;
            }

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }

        return loginSuccessful;
    }

    @Override
    public boolean register(User user) {
        Session session = sessionFactory.openSession();
        Transaction transaction = null;
        boolean registrationSuccessful = false;

        try {
            transaction = session.beginTransaction();
            session.save(user);
            transaction.commit();
            registrationSuccessful = true;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            session.close();
        }

        return registrationSuccessful;
    }
}
