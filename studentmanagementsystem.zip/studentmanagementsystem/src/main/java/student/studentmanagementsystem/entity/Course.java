package student.studentmanagementsystem.entity;

import java.util.List;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto Increment
    @Column
    private int courseId;
  
    @Size(min = 3, max = 100, message = "Course name must be between 3 and 100 characters")
    @Column
    private String courseName;
    
    @Min(value = 1, message = "Duration must be at least 1")
    @Column
    private int duration;

    //@ManyToOne
    //@JoinColumn(name = "department_id", nullable = false)
    //private Department department;

    // Default Constructor
    public Course() {}

    // Parameterized Constructor
    

    
    // Getters and Setters
    public int getCourseId() {
        return courseId;
    }



	public Course(int courseId,
			@Size(min = 3, max = 100, message = "Course name must be between 3 and 100 characters") String courseName,
			@Min(value = 1, message = "Duration must be at least 1") int duration) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.duration = duration;
	}

	public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        if (courseName == null || courseName.trim().isEmpty()) {
            throw new IllegalArgumentException("Course name cannot be empty.");
        }
        this.courseName = courseName;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        if (duration <= 0) {
            throw new IllegalArgumentException("Duration must be greater than 0.");
        }
        this.duration = duration;
    }

	@PrePersist
    @PreUpdate
    public void validateCourse() throws IllegalStateException {
        if (this.courseName == null || this.courseName.trim().isEmpty()) {
            throw new IllegalStateException("Course Name is required.");
        }
        if (this.duration <= 0) {
            throw new IllegalStateException("Duration must be greater than zero.");
        }
        //if (this.department == null) {
            //throw new IllegalStateException("Department is required.");
        //}
    }

	// Override toString method
    @Override
    public String toString() {
        return "Course [courseId=" + courseId + ", courseName=" + courseName + ", duration=" + duration
                +  "]";
    }
}
