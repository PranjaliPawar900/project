package student.studentmanagementsystem.entity;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.FetchType;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;

@Entity
@Table(name="Student")
public class Student {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int Student_id;

    @NotNull
    @Size(min = 1, max = 100)
    private String Student_Name;

    @NotNull
    @Size(min = 1, max = 100)
    private String Father_Name;

    @NotNull
    @Size(min = 1, max = 100)
    private String Last_Name;

    @NotNull
    @Size(min = 1, max = 200)
    private String Address;

    @NotNull
    @Size(min = 1, max = 100)
    private String City;

    @NotNull
    @Size(min = 1, max = 100)
    private String State;

    @Min(100000)
    @Max(999999)
    private int Pin_code;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits.")
    private Long Phone_no;

    @NotNull
    @Past
    private LocalDate DOB; // Use java.time.LocalDate for better handling

    @Min(18)
    @Max(100)
    private int Age;
    
    //@ManyToOne
   // @JoinColumn(name = "faculty_id", nullable = false)
    //private Faculty faculty;
    
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "Student_Course", // Join table name
        joinColumns = @JoinColumn(name = "student_id"), // Foreign key in join table for Student
        inverseJoinColumns = @JoinColumn(name = "course_id") // Foreign key in join table for Course
    )
    private Set<Course> courses = new HashSet<>();

    // Getter and Setter methods

	public void setStudent_id(int student_id) {
		Student_id = student_id;
	}



	public String getStudent_Name() {
		return Student_Name;
	}



	public void setStudent_Name(String student_Name) {
		Student_Name = student_Name;
	}



	public String getFather_Name() {
		return Father_Name;
	}



	public void setFather_Name(String father_Name) {
		Father_Name = father_Name;
	}



	public String getLast_Name() {
		return Last_Name;
	}



	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}



	public String getAddress() {
		return Address;
	}



	public void setAddress(String address) {
		Address = address;
	}



	public String getCity() {
		return City;
	}



	public void setCity(String city) {
		City = city;
	}



	public String getState() {
		return State;
	}



	public void setState(String state) {
		State = state;
	}

	public int getPin_code() {
		return Pin_code;
	}



	public void setPin_code(int  string) {
		Pin_code = string;
	}



	public Long getPhone_no() {
		return Phone_no;
	}



	public void setPhone_no(Long phone_no) {
		Phone_no = phone_no;
	}



	public LocalDate getDOB() {
		return DOB;
	}



	public void setDOB(LocalDate dOB) {
		DOB = dOB;
	}



	public int getAge() {
		return Age;
	}



	public void setAge(int age) {
		Age = age;
	}
	
	
	
	/*public Faculty getFaculty() {
		return faculty;
	}



	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}*/



	public Set<Course> getCourses() {
		return courses;
	}



	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}



	// Lifecycle callbacks for validation
    @PrePersist
    @PreUpdate
    
    public void validateStudent() throws IllegalStateException {
        if (this.Student_Name == null || this.Student_Name.isEmpty()) {
            throw new IllegalStateException("Student Name is required.");
        }
        if (this.Father_Name == null || this.Father_Name.isEmpty()) {
            throw new IllegalStateException("Father's Name is required.");
        }
        if (this.DOB == null) {
            throw new IllegalStateException("Date of Birth is required.");
        }
        if (this.Age <= 0) {
            throw new IllegalStateException("Age must be greater than zero.");
        }
        // Add more checks as necessary
    }

    

    public int  getStudent_id() {
		return Student_id;
	}



	// Custom validation logic
    public boolean isValid() {
        // Example: Check if DOB results in a valid age and if age matches the age field.
    	 // Validate age based on DOB
        if (DOB != null) {
            int calculatedAge = calculateAgeFromDob(DOB);
            if (calculatedAge != Age) {
                return false; // Invalid age, age calculated from DOB doesn't match the field
            }
            // Additional check: Ensure the student is at least 18 years old and at most 100
            if (calculatedAge < 18 || calculatedAge > 100) {
                return false; // Invalid age
            }
        }
        return true;
    }
    private int calculateAgeFromDob(LocalDate dob) {
        LocalDate currentDate = LocalDate.now();
        Period period = Period.between(dob, currentDate);
        return period.getYears();
    }

    // Override toString method with null safety
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Student [S_id=").append(Student_id)
          .append(", Student_Name=").append(Student_Name)
          .append(", Father_Name=").append(Father_Name)
          .append(", Last_Name=").append(Last_Name)
          .append(", Address=").append(Address)
          .append(", City=").append(City)
          .append(", State=").append(State)
          .append(", Pin_code=").append(Pin_code);
          sb.append(", Phone_no=").append(Phone_no);
          sb.append(",DOB =").append(DOB);
          sb.append(",Age =").append(Age);
          //sb.append(",faculty_id=").append(faculty);
        return sb.toString();
    }

	
}
