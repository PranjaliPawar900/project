package student.studentmanagementsystem.entity;

import java.util.ArrayList;
import java.util.List;

import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.entity.Student;
import jakarta.persistence.*;
import jakarta.validation.constraints.Pattern;
@Entity
@Table(name="faculty")

public class Faculty {
	@Id//indicating primary key
	@GeneratedValue(strategy=GenerationType.AUTO)//to generate auto increment
	    private int facultyId;
	    
	    @Column(name = "faculty_name", nullable = false)
	    private String facultyName;
	    
	    @Column(name = "salary", nullable = false)
	    private double salary;
	    
	    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits.")
	    @Column(name = "mob_no", nullable = false)
	    private long mobNo;
	    
	    // Creating many-to-one relationship with Department table
	    @ManyToOne(fetch = FetchType.LAZY)  // Lazy loading for better performance
	    @JoinColumn(name = "department_id", nullable = false)
	    private Department department;
	    
	    // Creating one-to-many relationship with Student table
	    //@OneToMany(mappedBy = "faculty", cascade = CascadeType.ALL)
	    //private List<Student> students = new ArrayList<>();  // Initialize to avoid NullPointerException

	    // Default constructor
	    public Faculty() {}

	    // Getter and Setter methods
	    public int getFacultyId() {
	        return facultyId;
	    }

	    public void setFacultyId(int facultyId) {
	        this.facultyId = facultyId;
	    }

	    public String getFacultyName() {
	        return facultyName;
	    }

	    public void setFacultyName(String facultyName) {
	        if (facultyName == null || facultyName.trim().isEmpty()) {
	            throw new IllegalArgumentException("Faculty name cannot be null or empty");
	        }
	        this.facultyName = facultyName;
	    }

	    public double getSalary() {
	        return salary;
	    }

	    public void setSalary(double salary) {
	        if (salary <= 0) {
	            throw new IllegalArgumentException("Salary must be greater than 0");
	        }
	        this.salary = salary;
	    }

	    public long getMobNo() {
	        return mobNo;
	    }

	    public void setMobNo(long mobNo) {
	        if (mobNo <= 0) {
	            throw new IllegalArgumentException("Mobile number must be greater than 0");
	        }
	        this.mobNo = mobNo;
	    }

	   
		public Department getDepartment() {
			return department;
		}

		public void setDepartment(Department department) {
			this.department = department;
		}

		/*public List<Student> getStudents() {
	        return students;
	    }

	    public void setStudents(List<Student> students) {
	        if (students == null) {
	            throw new IllegalArgumentException("Students list cannot be null");
	        }
	        this.students = students;
	    }*/

	    @Override
	    public String toString() {
	        return "Faculty [facultyId=" + facultyId + ", facultyName=" + facultyName + ", salary=" + salary + ", mobNo="
	                + mobNo + ", department=" + department +  "]";
	    }
}
