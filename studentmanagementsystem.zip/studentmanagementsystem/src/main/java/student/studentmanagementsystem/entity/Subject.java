package student.studentmanagementsystem.entity;

import java.util.ArrayList;
import java.util.List;

import  student.studentmanagementsystem.entity.Faculty;
import jakarta.persistence.*;
@Entity
@Table(name="subject")

public class Subject {
	@Id//indicating primary key
	@GeneratedValue(strategy=GenerationType.AUTO)//to generate auto increment
    private int Sub_id;
	private String Sub_Name;
	 @ManyToOne
	    @JoinColumn(name = "F_id")
	    private Faculty faculty;
	public int getSub_id() {
		return Sub_id;
	}
	public void setSub_id(int sub_id) {
		Sub_id = sub_id;
	}
	public String getSub_Name() {
		return Sub_Name;
	}
	public void setSub_Name(String sub_Name) {
		Sub_Name = sub_Name;
	}
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public Subject() {
		super();
	}
	
	
	public Subject(int sub_id, String sub_Name, Faculty faculty) {
		super();
		Sub_id = sub_id;
		Sub_Name = sub_Name;
		//this.faculty = faculty;
	}
	@Override
	public String toString() {
		return "Subject [Sub_id=" + Sub_id + ", Sub_Name=" + Sub_Name +  "]";
	}
	 
}
