package student.studentmanagementsystem.entity;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "department")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long departmentId;

    @Column(name = "dName", nullable = false)
    private String dName;

    // One-to-many relationship with Faculty
    @OneToMany(mappedBy = "department", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Faculty> faculties = new ArrayList<>();

    // Default constructor
    public Department() {}

    // Parameterized constructor
    public Department(String dName) {
        this.dName = dName;
    }

    // Getters and Setters
   

    public String getdName() {
        return dName;
    }

    public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public void setdName(String dName) {
        if (dName == null || dName.trim().isEmpty()) {
            throw new IllegalArgumentException("Department name cannot be empty.");
        }
        this.dName = dName;
    }
    public List<Faculty> getFaculties() {
        return faculties;
    }

    public void setFaculties(List<Faculty> faculties) {
        this.faculties = faculties;
    }

    // Validation method
    @PrePersist
    @PreUpdate
    public void validateDepartment() {
        if (this.dName == null || this.dName.trim().isEmpty()) {
            throw new IllegalStateException("Department Name is required.");
        }
    }

    // Override the toString method for better readability
    @Override
    public String toString() {
        return "Department [departmentId=" + departmentId + ", dName=" + dName + "]";
    }
}
