/*package student.studentmanagementsystem.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import student.studentmanagementsystem.entity.Admin;
import student.studentmanagementsystem.entity.Course;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.entity.Faculty;
import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.entity.Subject;
import student.studentmanagementsystem.entity.User;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    // Method to return a SessionFactory instance
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                // Create Configuration instance
                Configuration configuration = new Configuration();

                // Set Hibernate properties
                Properties settings = new Properties();
                settings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
                settings.put(Environment.URL, "jdbc:mysql://localhost:3306/studentmansys?useSSL=false&serverTimezone=UTC");
                settings.put(Environment.USER, "root");
                settings.put(Environment.PASS, "1234");
                settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL8Dialect");
                settings.put(Environment.SHOW_SQL, true);
                settings.put(Environment.FORMAT_SQL, true);
                settings.put(Environment.HBM2DDL_AUTO, "update");

                // Apply the settings to the configuration
                configuration.setProperties(settings);

                // Add annotated entity classes
                configuration.addAnnotatedClass(User.class);
                configuration.addAnnotatedClass(Admin.class);
                configuration.addAnnotatedClass(Student.class);
                configuration.addAnnotatedClass(Course.class);
                configuration.addAnnotatedClass(Faculty.class);
                configuration.addAnnotatedClass(Department.class);
                configuration.addAnnotatedClass(Subject.class);

                // Build ServiceRegistry
                ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                        .applySettings(configuration.getProperties())
                        .build();

                // Build the SessionFactory
                sessionFactory = configuration.buildSessionFactory(serviceRegistry);

            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("SessionFactory initialization failed: " + e.getMessage());
            }
        }
        return sessionFactory;
    }
}*/

package student.studentmanagementsystem.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import student.studentmanagementsystem.entity.Admin;
import student.studentmanagementsystem.entity.Course;
import student.studentmanagementsystem.entity.Department;
import student.studentmanagementsystem.entity.Faculty;
import student.studentmanagementsystem.entity.Student;
import student.studentmanagementsystem.entity.Subject;
import student.studentmanagementsystem.entity.User;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    // Method to return a SessionFactory instance
    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                // Create Configuration instance
                Configuration configuration = new Configuration();

                // Set Hibernate properties
                Properties settings = new Properties();
                settings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
                settings.put(Environment.URL, "jdbc:mysql://localhost:3306/studentmangementsys?useSSL=false&serverTimezone=UTC");
                settings.put(Environment.USER, "root");
                settings.put(Environment.PASS, "system22");
                settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL8Dialect");
                settings.put(Environment.SHOW_SQL, true); // Show SQL queries
                settings.put(Environment.FORMAT_SQL, true); // Format SQL queries
                settings.put(Environment.HBM2DDL_AUTO, "update"); // Auto-generate schema

                // Apply the settings to the configuration
                configuration.setProperties(settings);

                // Add annotated entity classes
                configuration.addAnnotatedClass(User.class);
                configuration.addAnnotatedClass(Admin.class);
                configuration.addAnnotatedClass(Student.class);
                configuration.addAnnotatedClass(Course.class);
                configuration.addAnnotatedClass(Faculty.class);
                configuration.addAnnotatedClass(Department.class);
                configuration.addAnnotatedClass(Subject.class);

                // Build ServiceRegistry
                ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                        .applySettings(configuration.getProperties())
                        .build();

                // Build the SessionFactory
                sessionFactory = configuration.buildSessionFactory(serviceRegistry);

            } catch (Exception e) {
                e.printStackTrace();
                System.err.println("SessionFactory initialization failed: " + e.getMessage());
            }
        }
        return sessionFactory;
    }

    // Close the SessionFactory (when no longer needed)
    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}

